<template>
<div class="">
    #[[$END$]]#
</div>
</template>

<script>
export default {
    name: '${NAME}',
    components:{},
    data() {
      return {};
    },
    computed:{},
    props:{},
    watch:{},
    created(){},
    mounted(){},
    methods: {},
    filters:{}
};
</script>

<style scoped lang="stylus">

</style>