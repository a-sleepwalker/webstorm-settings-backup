import React, {Component} from 'react';

class $NAME extends Component {
  render() {
    return  #[[$END$]]#
  }
}